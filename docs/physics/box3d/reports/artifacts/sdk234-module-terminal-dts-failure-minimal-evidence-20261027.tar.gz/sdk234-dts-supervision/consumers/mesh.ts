import { MeshCollider, Mesh, Vec3 } from '../../sdk234-dts-source/build/cocosair.module.js';
declare const collider: MeshCollider;
const mesh: Mesh | null = collider.mesh;
const center: Vec3 = collider.center;
void mesh; void center;
