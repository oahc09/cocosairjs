import { TerrainCollider } from '../../sdk235-dts-source/build/cocosair.module.js';
declare const collider: TerrainCollider;
declare const asset: NonNullable<TerrainCollider['terrain']>;
collider.terrain = asset;
const shape: TerrainCollider['shape'] = collider.shape;
void shape;
