import { createAirApp, AirApp, AirSceneReleaseReceipt } from '../../sdk235-dts-source/build/cocosair.module.js';
declare const app: AirApp;
const release: Promise<AirSceneReleaseReceipt> | undefined = app.releaseScene?.();
const make: typeof createAirApp = createAirApp;
void release; void make;
