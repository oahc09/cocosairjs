#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
import os,time,json,hashlib,pathlib,stat,subprocess,signal,ctypes,fcntl,resource,importlib.util
P=pathlib.Path(__file__).resolve().parent;R=P.parent;C=json.loads((P/'control.json').read_text());S=pathlib.Path(C['source']);E=pathlib.Path(C['evidence']);OUT=pathlib.Path(C['out']);start=time.monotonic();deadline=start+C['totalSeconds']
def now():return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def put(p,o):
 with open(p,'x') as f:json.dump(o,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def row(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def available():return int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
def guard():
 if time.monotonic()>=deadline:raise TimeoutError('TOTAL_DEADLINE')
def inspect():
 result={}
 for root in map(pathlib.Path,C['protectedRoots']):
  todo=[root]
  while todo:
   guard();p=todo.pop()
   if any(p==pathlib.Path(x) or pathlib.Path(x) in p.parents for x in C['excludedExactTrees']):continue
   st=p.lstat();v={'mode':st.st_mode}
   if stat.S_ISLNK(st.st_mode):v['target']=os.readlink(p)
   elif stat.S_ISREG(st.st_mode):v.update(bytes=st.st_size,sha256=sha(p))
   elif stat.S_ISDIR(st.st_mode):todo.extend(p.iterdir())
   else:raise RuntimeError('Unsupported input type '+str(p))
   result[str(p)]=v
 return result
def measure(root,dynamic=True):
 n=0;latest=0
 if not root.exists():return n,latest
 for parent,ds,fs in os.walk(root,followlinks=False,onerror=lambda e: (_ for _ in ()).throw(e)):
  for name in fs:
   try:
    st=os.lstat(os.path.join(parent,name));n+=st.st_size;latest=max(latest,st.st_mtime_ns)
   except FileNotFoundError:
    if not dynamic:raise
 return n,latest
# Reuse only reviewed read-only descendant discovery and PID-starttime-safe signalling.
spec=importlib.util.spec_from_file_location('closure_core',pathlib.Path(C['producerSource'])/'tools/physics/box3d/lifecycle-contract/lowlevel/supervise.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
assert sys.argv[1:]==['--execute-approved-once'];assert os.environ.get('BOX3D_WINDOW')==C['window']
lock=open(R/'build-stage.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not E.exists() and OUT.is_dir() and not list(OUT.iterdir());E.mkdir();(E/'tmp').mkdir();put(P/'attempt.once',{'at':now(),'pid':os.getpid()})
resource.setrlimit(resource.RLIMIT_CORE,(0,0));assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
child=None;rc=None;echild=False;abort=None;peak=0;waits=[];baseline=None;changes=[];samples=0;external=None
result={'status':'FAIL_OR_PARTIAL','startedAt':now(),'sourceProducer':C['sourceCommit'],'budget':C,'commands':[]}
def sig(sig,_):
 global external
 external=sig
signal.signal(signal.SIGTERM,sig);signal.signal(signal.SIGINT,sig)
def reap():
 global rc
 while True:
  try:pid,status=os.waitpid(-1,os.WNOHANG)
  except ChildProcessError:return True
  if pid==0:return False
  waits.append({'pid':pid,'rawWaitStatus':status,'exitCode':os.waitstatus_to_exitcode(status)})
  if child and pid==child.pid:rc=os.waitstatus_to_exitcode(status);child.returncode=rc
try:
 assert available()>=C['startAvailableBytes'],'START_MEMORY_LOW'
 baseline=inspect();put(P/'protected-inputs.json',baseline);guard()
 assert not (P/'cancel').exists();assert time.monotonic()-start<C['stopSeconds']
 env=os.environ.copy()
 for k in list(env):
  if k.startswith(('AIR_','BOX3D_','NODE_OPTIONS','NODE_PATH')):env.pop(k)
 env.update(TMPDIR=str(E/'tmp'),TMP=str(E/'tmp'),TEMP=str(E/'tmp'),PYTHONDONTWRITEBYTECODE='1')
 out=(E/'stdout.raw').open('xb');err=(E/'stderr.raw').open('xb')
 child=subprocess.Popen(C['command'],cwd=S,env=env,stdout=out,stderr=err,start_new_session=True)
 put(E/'child-start.json',{'at':now(),'pid':child.pid,'pgid':child.pid});print(json.dumps({'event':'START','pid':child.pid,'at':now(),'evidence':str(E)}),flush=True)
 last_activity=time.monotonic();last_fingerprint=None
 with (E/'resources.jsonl').open('x') as log:
  while rc is None:
   reap()
   if rc is not None:break
   members=core.descendants();rss=sum(x['rssBytes'] for x in members);peak=max(peak,rss)
   size,mtime=measure(OUT);diag,dmtime=measure(E);finger=(size,mtime,diag and (E/'stdout.raw').stat().st_size,(E/'stderr.raw').stat().st_size)
   if finger!=last_fingerprint:last_activity=time.monotonic();last_fingerprint=finger
   elapsed=time.monotonic()-start;av=available();samples+=1
   sample={'elapsed':elapsed,'rssBytes':rss,'outputBytes':size,'diagnosticBytes':diag,'availableBytes':av};log.write(json.dumps(sample)+'\n');log.flush()
   (P/'heartbeat.json').write_text(json.dumps({'at':now(),'pid':os.getpid(),**sample}))
   if external:abort='EXTERNAL_SIGNAL'
   elif (P/'cancel').exists():abort='CANCEL'
   elif elapsed>=C['stopSeconds']:abort='STOP_DEADLINE'
   elif rss>C['rssBytes']:abort='TREE_RSS_LIMIT'
   elif av<C['reserveBytes']:abort='SYSTEM_MEMORY_RESERVE'
   elif size+measure(E/'tmp')[0]>C['outputBytes']:abort='OUTPUT_LIMIT'
   elif diag>C['diagnosticBytes']+measure(E/'tmp')[0]:abort='DIAGNOSTIC_LIMIT'
   elif time.monotonic()-last_activity>C['stallSeconds']:abort='NO_OUTPUT_ACTIVITY'
   if abort:break
   time.sleep(0.5)
 out.close();err.close()
except BaseException as ex:abort=abort or repr(ex)
finally:
 close_end=min(deadline,time.monotonic()+8);term_end=time.monotonic()+1
 while time.monotonic()<close_end:
  echild=reap();members=core.descendants()
  if echild and not members:break
  core.signal_owned(members,signal.SIGTERM if time.monotonic()<term_end else signal.SIGKILL);time.sleep(.05)
 echild=reap();members=core.descendants()
 result.update(exitCode=rc,physicalClose='ECHILD' if echild and not members else 'NOT_CLOSED',rawWaitRows=waits,remainingDescendants=members,peakSampledTreeRSSBytes=peak,samples=samples,processClosedAt=now(),elapsedToProcessCloseSeconds=time.monotonic()-start)
 try:
  assert baseline is not None,'NO_BASELINE';post=inspect();changes=[p for p in sorted(set(baseline)|set(post)) if baseline.get(p)!=post.get(p)];assert not changes,'INPUT_DRIFT'
  assert rc==0 and echild and not members and abort is None,'BUILD_OR_CLOSE_FAILED'
  SDK=pathlib.Path(C['sdk']);gates=json.loads((E/'seven-gates.json').read_text());assert len(gates)==7 and all(x['exitCode']==0 for x in gates)
  assert [x['command'] for x in gates]==json.loads((P/'driver.json').read_text())['commands']
  import re
  emitDiagnosticLines=[line for line in (E/'gate-1.stderr').read_text().splitlines() if re.search(r'\.tsx? \(\d+,\d+\):',line)]
  assert not emitDiagnosticLines,('EMIT_SOURCE_DIAGNOSTICS',emitDiagnosticLines)
  modern=OUT/'cocosair.module.d.ts';legacy=OUT/'cocosair.legacy.d.ts';assert modern.stat().st_size>0
  template=(S/'tools/build/legacy-dom-types.cjs').read_text().split('const declaration = `',1)[1].split('`;',1)[0].encode()
  assert legacy.read_bytes()==template and len(template)==367 and b"./cocosair.module.js" in template
  assert 'TerrainCollider' in modern.read_text() and 'createAirApp' in modern.read_text()
  for x in C['esmFiles']:assert sha(SDK/x['path'])==x['sha256'] and (SDK/x['path']).stat().st_size==x['bytes']
  assert json.loads((pathlib.Path(C['producerSource'])/'tools/build/build-number.json').read_text())['lastBuildNumber']==235
  assert not (SDK/modern.name).exists() and not (SDK/legacy.name).exists()
  declarations=[]
  for p in [modern,legacy]:
   with (SDK/p.name).open('xb') as f:f.write(p.read_bytes())
   assert sha(SDK/p.name)==sha(p);declarations.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p),'emittedSource':str(p)})
  finalProtected=inspect();assert finalProtected==baseline,'POST_PROMOTION_INPUT_DRIFT'
  result.update(sourceCommit=C['sourceCommit'],buildNumber=235,declarations=declarations,sevenGatesSha256=sha(E/'seven-gates.json'),sevenGates=gates,emitSourceDiagnosticLines=emitDiagnosticLines,canonicalLegacySource=row(S/'tools/build/legacy-dom-types.cjs'),physicalClose='ECHILD_AND_NO_GROUP_MEMBERS',postInputDrift=changes)
  size,_=measure(OUT,False);diag,_=measure(E,False);assert size+measure(E/'tmp',False)[0]<=C['outputBytes'] and diag-measure(E/'tmp',False)[0]<=C['diagnosticBytes'];guard()
  result['status']='PASS_FRESH_DTS235_SEVEN_GATES'
 except BaseException as ex:abort=abort or repr(ex)
 result.update(abort=abort,inputDrift=changes,finishedAt=now(),elapsedSeconds=time.monotonic()-start,outputBytes=measure(OUT)[0],diagnosticBytesBeforeResult=measure(E)[0])
 if time.monotonic()>=deadline:result['status']='FAIL_OR_PARTIAL';result['abort']=result['abort'] or 'TOTAL_DEADLINE'
 resultBytes=len((json.dumps(result,indent=2)+'\n').encode()); completeReserve=1024 if result['status'].startswith('PASS_') else 0
 if measure(E,False)[0]-measure(E/'tmp',False)[0]+resultBytes+completeReserve>C['diagnosticBytes']:
  result['status']='FAIL_OR_PARTIAL';result['abort']=result['abort'] or 'FINAL_DIAGNOSTIC_LIMIT'
 put(E/'result.json',result)
 if result['status'].startswith('PASS_'):
  guard();put(E/'complete.json',{'result':row(E/'result.json'),'at':now()})
 finalMeasured=measure(E,False)[0];assert finalMeasured-measure(E/'tmp',False)[0]<=C['diagnosticBytes']
 print(json.dumps({'status':result['status'],'abort':result['abort'],'physicalClose':result['physicalClose'],'result':row(E/'result.json')}),flush=True)
fcntl.flock(lock,fcntl.LOCK_UN);sys.exit(0 if result['status'].startswith('PASS_') else 1)
