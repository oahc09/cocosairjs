import pathlib,json,subprocess,time,os,sys
P=pathlib.Path(__file__).resolve().parent;c=json.loads((P/'driver.json').read_text());E=pathlib.Path(c['evidence']);started=time.monotonic();rows=[]
for i,command in enumerate(c['commands'],1):
 if (P/'cancel').exists() or time.monotonic()-started>=265:raise RuntimeError('driver deadline/cancel')
 with (E/f'gate-{i}.stdout').open('xb') as out,(E/f'gate-{i}.stderr').open('xb') as err:
  r=subprocess.run(command,cwd=c['cwd'],stdout=out,stderr=err)
 rows.append({'index':i,'command':command,'cwd':c['cwd'],'exitCode':r.returncode});(E/'seven-gates.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
