APP230 original raw evidence package.
Not self-contained: SDK binaries, complete source and dependency bytes are excluded.
CONTENTS.json records SHA256 and byte size for every retained original.
Absolute task paths in original receipts are retained, not rewritten.
Only five explicitly approved non-secret build-variable assignments are included; no environment dump.
Already published frozen fixture source copies are excluded and listed separately.
Historical APP228 failure / APP229 not run / unavailable old raw remain unchanged.
