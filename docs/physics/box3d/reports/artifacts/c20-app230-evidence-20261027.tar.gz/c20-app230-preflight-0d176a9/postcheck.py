"""Read retained evidence and rehash protected inputs only; no SDK/native imports."""
from pathlib import Path
import json,hashlib,os
R=Path('/workspace/scratch/62d43a81bbde/box3d-recovery-20261027T0928');P=R/'c20-app230-preflight-0d176a9';O=R/'c20-app230-attempt-1';X=R/'c20-app230-source-0d176a9-attempt-1'
def read(p):return json.loads(p.read_text())
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def row(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':digest(p)}
def size(p):return sum(x.stat().st_size for x in p.rglob('*') if x.is_file())
def ensure_hash(r):
 p=Path(r['path']);assert p.is_file() and p.stat().st_size==r['bytes'] and digest(p)==r['sha256'],r['path']
outer=read(O/'result.json');closure=read(O/'main/closure.json');freeze=read(O/'preparation/freeze/closure.json');consumer=read(O/'main/run/result/consumer.raw.json');process=read(O/'main/run/process.raw.json');protected=read(O/'preparation/protected-inputs.json')['files'];preflight=read(P/'preflight-lock.json')
for r in protected+preflight['preparationFiles']+[preflight['sourceCandidateManifest']]:ensure_hash(r)
link=preflight['dependencyLink'];assert os.readlink(link['path'])==link['target'] and str(Path(link['path']).resolve())==link['resolved']
for c in [freeze,closure]:
 assert c['status']=='PHYSICALLY_CLOSED' and c['subreaper'] is True and c['waitpidECHILD'] is True and c['waitpidScope']=='ALL_CHILDREN_-1' and c['remainingDescendants']==[] and c['remainingProcessGroup']==[] and c['budgetViolation'] is None
assert outer['status']==consumer['strictStatus']==process['status']=='PASS_LIMITED_C20APP_OBSERVABLE_SUBSET'
assert outer['rawReturnCode']==0 and outer['protectedInputChanges']==[] and consumer['inputsUnchanged'] is True
assert consumer['completedCycles']==len(consumer['cycles'])==100 and consumer['totalSteps']==len(consumer['frames'])==5800
assert consumer['appCreateCalls']==consumer['appCloseCalls']==1
assert consumer['close']['status']=='released' and consumer['close']['pending']==consumer['close']['failures']==[]
assert consumer['close']['physicsPreparation']['status']=='closed' and consumer['close']['physicsPreparation']['cleanupErrors']==[]
assert all(r['cleanup']=='released' for r in consumer['close']['physicsPreparation']['acquired'])
diag=[json.loads(l) for l in (O/'main/run/result/memory-diagnostics.raw.jsonl').read_text().splitlines()]
assert len(diag)==consumer['memoryDiagnostics']['attemptedSnapshots']==consumer['memoryDiagnostics']['validatedSnapshots']==201
assert consumer['memoryDiagnosticStatus']=='COMPLETE_REACHED_SCENE_SNAPSHOT_SETS' and consumer['memoryDiagnostics']['errors']==[]
assert diag==consumer['memoryDiagnostics']['observations']
assert all(r['status']=='OBSERVED_VALIDATED' for r in diag)
released=[r for r in diag if r['kind']=='released-cycle-before-validation'];assert len(released)==100
assert all(r['observation']['worldLedger']['coreReportedBytes']=='36096' and len(r['observation']['worldLedger']['rows'])==89 for r in [diag[0],*released])
assert len({r['observation']['identity']['worldId'] for r in diag})==len({r['observation']['identity']['bindingGeneration'] for r in diag})==1
for index,c in enumerate(consumer['cycles'],1):
 assert c['cycle']==index and c['status']=='COMPLETE' and c['phase']=='complete'
 assert c['sceneRunCalls']==c['releaseSceneCalls']==c['sessionCleanupCalls']==1
 assert [c[k] for k in ['createdBodies','createdShapes','createdTerrainUsers','createdJoints']]==[50,50,3,1]
 assert c['afterRelease']==consumer['baseline'] and c['release']['status']=='released' and c['release']['physicsSceneRelease']['status']=='RESTORED'
 assert c['release']['pending']==c['release']['failures']==[] and c['stepsDuringRelease']==0
 assert all(c[k] is True for k in ['sceneInvalid','currentSceneNull','allPreviousTokensStale','previousCallbacksUnchanged','eventCopiesUnchanged','materialInvalid','sameApp','sameClock','sameWorldDiagnosticObject'])
 assert c['oldTokenCurrent'] is False and len(c['events'])==108
 assert [c['active']['native'][k] for k in ['bodies','shapes','joints']]==[50,50,1]
 assert c['active']['resources'][0]['users']==c['active']['resources'][0]['shapeBorrows']==3 and c['active']['resources'][0]['cacheLeases']==1
 assert c['jointBeforeFirstStep']['breakForce']==c['jointBeforeFirstStep']['breakTorque']==100000000 and c['jointBeforeFirstStep']['step']==c['startStep']
assert read(P/'dependencies.after.json')['status']=='UNCHANGED'
assert read(P/'dependencies.before-launch.json')['status']=='UNCHANGED'
copy=read(P/'st-copy-receipt.json');
for name in ['producerRoot','executionRoot']:
 root=Path(copy[name])/copy['relativeOUT'];files=sorted(p for p in root.rglob('*') if p.is_file());assert len(files)==copy['fileCount']
 for e in copy['files']:
  p=root/e['path'];assert p.stat().st_size==e['bytes'] and digest(p)==e['sha256']
summary={'schema':'box3d-app230-postcheck-v1','status':'PASS_READ_ONLY_POSTCHECK','scope':'Current100scene limited observable subset only; no after-close getter or full C20/I05/I06 census','fixtureCommit':outer['producerIdentity']['fixtureCommit'],'producerIdentity':outer['producerIdentity'],'completedCycles':100,'publicSteps':5800,'callbacks':10800,'appCreates':1,'appCloses':1,'diagnosticSnapshots':201,'originalWorldLedgerBaseline':'36096','releasedLedgerDistinct':sorted({r['observation']['worldLedger']['coreReportedBytes'] for r in released}),'moduleCoreRequestedBytes':{'initial':diag[0]['observation']['moduleCoreTrackedRequestedBytes'],'releasedDistinct':sorted({r['observation']['moduleCoreTrackedRequestedBytes'] for r in released})},'worldBridgeBytes':{'initial':diag[0]['observation']['nativeWorldBridge']['trackedBytes'],'releasedDistinct':sorted({r['observation']['nativeWorldBridge']['trackedBytes'] for r in released})},'globalBridgeBytes':{'initial':diag[0]['observation']['nativeGlobalBridge']['trackedBytes'],'releasedDistinct':sorted({r['observation']['nativeGlobalBridge']['trackedBytes'] for r in released})},'protectedRecordsRehashed':len(protected),'protectedUniquePaths':len({r['path'] for r in protected}),'inputDrift':[],'dependencyProtection':read(P/'dependencies.after.json'),'copySTFilesRehashedPerRoot':copy['fileCount'],'close':{'app':'released','moduleAndWorldCleanup':'released','allDescendants':'ALL_CHILDREN_-1_ECHILD_NO_GROUP_MEMBERS','outerRawReturnCode':0},'measurements':{'mainWallSeconds':closure['elapsedSeconds'],'closeSeconds':closure['closeSeconds'],'peakSampledDescendantRSSBytes':closure['peakSampledDescendantRSSBytes'],'RSSQualification':closure['rssQualification']},'history':consumer['historicalReplay'],'budget':{'mainLimit':58720256,'preparationLimit':8388608,'combinedLimit':67108864,'externalPreparationBytes':0,'mainOutputBytes':size(O/'main'),'combinedPreparationBytes':0,'combinedOutputBytes':0},'originals':[row(p) for p in [O/'result.json',O/'main/closure.json',O/'main/run/process.raw.json',O/'main/run/result/consumer.raw.json',O/'main/run/result/observations.raw.jsonl',O/'main/run/result/memory-diagnostics.raw.jsonl',O/'preparation/input-lock.json',O/'preparation/protected-inputs.json',P/'dependencies.before.json',P/'dependencies.after.json',P/'preflight-lock.json',P/'st-copy-receipt.json']]}
p=P/'postcheck.json';assert not p.exists();base=size(P);prep=size(O/'preparation');total=size(O)
for _ in range(12):
 n=len((json.dumps(summary,indent=2)+'\n').encode());b=summary['budget'];new={'externalPreparationBytes':base+n,'combinedPreparationBytes':base+n+prep,'combinedOutputBytes':base+n+total}
 if all(b[k]==v for k,v in new.items()):break
 b.update(new)
b=summary['budget'];assert b['mainOutputBytes']<b['mainLimit'] and b['combinedPreparationBytes']<b['preparationLimit'] and b['combinedOutputBytes']<b['combinedLimit']
with p.open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
assert size(P)==b['externalPreparationBytes'] and size(O)+size(P)==b['combinedOutputBytes']
print(json.dumps({'status':summary['status'],'postcheck':row(p),'budget':b,'cycles':100,'protectedRecords':len(protected),'uniquePaths':summary['protectedUniquePaths'],'module':summary['moduleCoreRequestedBytes'],'worldBridge':summary['worldBridgeBytes']}))
