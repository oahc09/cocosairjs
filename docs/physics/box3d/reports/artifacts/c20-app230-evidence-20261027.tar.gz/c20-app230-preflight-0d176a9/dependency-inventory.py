"""Read-only exact dependency entity/link protection; never imports packages."""
import os,stat,json,hashlib,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True

def snapshot(root):
 root=Path(root).resolve(strict=True);rows=[]
 def scan(p):
  s=p.lstat();rel='.' if p==root else p.relative_to(root).as_posix();r={'path':rel,'mode':stat.S_IMODE(s.st_mode)}
  if stat.S_ISLNK(s.st_mode):
   target=os.readlink(p);resolved=p.resolve(strict=True);assert resolved.is_relative_to(root),('escaping dependency link',rel,target)
   r.update(kind='symlink',target=target,resolved=resolved.relative_to(root).as_posix());assert os.readlink(p)==target
  elif stat.S_ISDIR(s.st_mode):
   r['kind']='directory';rows.append(r)
   for child in sorted(p.iterdir(),key=lambda p:p.name):scan(child)
   return
  elif stat.S_ISREG(s.st_mode):
   fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
   with os.fdopen(fd,'rb') as f:
    a=os.fstat(f.fileno());h=hashlib.file_digest(f,'sha256').hexdigest();b=os.fstat(f.fileno())
   c=p.lstat();fields=lambda q:(q.st_dev,q.st_ino,q.st_mode,q.st_size,q.st_mtime_ns)
   assert fields(s)==fields(a)==fields(b)==fields(c),('dependency changed while hashing',rel)
   r.update(kind='file',bytes=s.st_size,sha256=h)
  else:raise AssertionError(('unsupported dependency entity',rel))
  rows.append(r)
 scan(root);rows.sort(key=lambda r:r['path']);encoded=(json.dumps(rows,separators=(',',':'),sort_keys=True)+'\n').encode()
 return {'root':str(root),'records':rows,'inventorySha256':hashlib.sha256(encoded).hexdigest(),'files':sum(r['kind']=='file' for r in rows),'links':sum(r['kind']=='symlink' for r in rows),'directories':sum(r['kind']=='directory' for r in rows),'fileBytes':sum(r.get('bytes',0) for r in rows)}
def selftest():
 with tempfile.TemporaryDirectory() as d:
  p=Path(d);(p/'a').write_text('one');base=snapshot(p)
  (p/'a').write_text('two');assert snapshot(p)!=base
  (p/'a').write_text('one');assert snapshot(p)==base
  (p/'empty').mkdir();assert snapshot(p)!=base;(p/'empty').rmdir()
  (p/'link').symlink_to('a');s=snapshot(p);assert s['links']==1
  (p/'link').unlink();(p/'link').symlink_to('/etc/passwd')
  try:snapshot(p);raise RuntimeError('escaping link accepted')
  except AssertionError:pass
  (p/'link').unlink();(p/'link').symlink_to('absent')
  try:snapshot(p);raise RuntimeError('broken link accepted')
  except FileNotFoundError:pass
  (p/'link').unlink();(p/'a').unlink();assert snapshot(p)!=base
 print(json.dumps({'status':'PASS_CPU_ONLY','checks':7,'packagesImported':False}))
if __name__=='__main__':
 if sys.argv[1:]==['--self-test']:selftest()
 elif sys.argv[1]=='--create':
  s=snapshot(sys.argv[2]);Path(sys.argv[3]).write_text(json.dumps(s,separators=(',',':'))+'\n');print(json.dumps({k:v for k,v in s.items() if k!='records'}))
 elif sys.argv[1]=='--check':
  before=json.loads(Path(sys.argv[3]).read_text());after=snapshot(sys.argv[2]);assert after==before,'Dependency entity/link/hash drift';print(json.dumps({'status':'UNCHANGED',**{k:v for k,v in after.items() if k!='records'}}))
 else:raise SystemExit('Use --self-test, --create ROOT OUT, or --check ROOT BEFORE')
