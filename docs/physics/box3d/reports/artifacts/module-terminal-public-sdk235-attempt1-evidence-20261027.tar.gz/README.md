# SDK235 public normal-close module terminal receipt evidence

PASS_PUBLIC_MODULE_RELEASE_SUBSET: one app/scene, four bodies/four shapes,
one joint, two Terrain users sharing one resource/one native cache lease/two
shape borrows, nonempty copied debug snapshot, two completed public frames.
One normal app.close; no fallback, new factory or post-close native probe.
The original-module terminal snapshot is taken inside loader cleanup; the
returned copied receipt is VERIFIED, original baseline and terminal both
core worlds0/core tracked requested bytes0, registered bridge/mesh fields0.
Exit0/ECHILD and3072 protected records with zero drift.

This is one headless normal-close subset, NOT full C20/I05/I06/T15, all native
handles, malloc, heap or garbage collection qualification. CPU/source copied-
receipt immutability/no-strong-reference controls are NOT GC runtime proof.
SDK234 DTS FAIL and all historical failures/missing evidence remain unchanged.

CONTENTS.json binds every original byte/SHA256, including all report-indexed
originals, journals, closure/lock/postcheck/producer receipts, supervision
logs and individually indexed public fixture source. Excludes SDK/native
binaries, dependencies, full source tree, duplicate frozen imports/harness
and duplicate consumer input lock. Only exact non-secret build assignments
are allowlisted. No original modified; no runtime rerun. This is durable
evidence, not a self-contained SDK/source/dependency replay project.
