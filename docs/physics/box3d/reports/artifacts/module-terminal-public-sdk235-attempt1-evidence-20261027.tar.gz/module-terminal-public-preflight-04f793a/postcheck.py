"""Read-only postchecks plus one exclusive summary; never imports SDK or advances physics."""
import os,stat,json,hashlib
from pathlib import Path
R=Path('/workspace/scratch/62d43a81bbde/box3d-recovery-20261027T0928');P=R/'module-terminal-public-preflight-04f793a';O=R/'module-terminal-public-attempt-1';X=R/'module-terminal-public-source-04f793a-attempt-1'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def row(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(record,base=None):
 p=(base/record['path']) if base else Path(record['path']);assert stat.S_ISREG(p.lstat().st_mode);assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],str(p)
def inventory(root):
 rows=[]
 def scan(p):
  s=p.lstat();rel=p.relative_to(root).as_posix()
  if stat.S_ISLNK(s.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)});return
  if stat.S_ISDIR(s.st_mode):
   for c in sorted(p.iterdir()):scan(c)
  else:
   assert stat.S_ISREG(s.st_mode);rows.append({'kind':'file','path':rel,'bytes':s.st_size,'sha256':sha(p)})
 scan(root);return rows
def size(root):
 assert stat.S_ISDIR(root.lstat().st_mode)
 def fail(e):raise e
 total=0
 for current,dirs,files in os.walk(root,onerror=fail,followlinks=False):
  for d in dirs:assert stat.S_ISDIR((Path(current)/d).lstat().st_mode)
  for f in files:
   v=(Path(current)/f).lstat();assert stat.S_ISREG(v.st_mode);total+=v.st_size
 return total
result=read(O/'result.json');consumer=read(O/'main/run/result/consumer.raw.json');process=read(O/'main/run/process.raw.json');closure=read(O/'main/closure.json');lock=read(O/'preparation/input-lock.json');prep=read(P/'preparation-result.json')
assert result['status']=='PASS_PUBLIC_MODULE_RELEASE_SUBSET' and result['rawReturnCode']==0 and result['allDescendantsClosed'] is True
assert process['status']=='PASS_PUBLIC_MODULE_RELEASE_SUBSET' and [(r['label'],r['status'],r['signal']) for r in process['processes']]==[('cpu-controls',0,None),('consumer',0,None)]
assert consumer['status']==consumer['fixtureStatus']=='PASS_PUBLIC_MODULE_RELEASE_SUBSET'
assert consumer['frames']==[{'step':n,'dt':1/60,'afterDraw':True} for n in range(1,3)] and consumer['completedFrames']==2
assert (consumer['appCreateCalls'],consumer['sceneRunCalls'],consumer['releaseSceneCalls'],consumer['closeCalls'])==(1,1,1,1)
assert consumer['fallbackCloseCalls']==0 and consumer['fixtureOwnCloseObserved'] is True and consumer['moduleFactoryReplaced'] is False
assert consumer['nonempty']=={'bodies':4,'shapes':4,'contacts':0,'joints':1,'liveBytes':'49460'}
assert len(consumer['activeResources'])==1
mesh=consumer['activeResources'][0];assert (mesh['users'],mesh['cacheLeases'],mesh['shapeBorrows'],mesh['vertexCount'],mesh['triangleCount'],mesh['coreMeshBytes'])==(2,1,2,9,8,416)
assert consumer['joint']['state']=='connected' and consumer['joint']['native']['breakForce']==consumer['joint']['native']['breakTorque']==100000000
assert len(consumer['debug']['primitives'])>0 and consumer['debugRetainedAfterClose'] is True
assert consumer['release']['status']=='released' and consumer['release']['physicsSceneRelease']['status']=='RESTORED'
assert consumer['release']['failures']==consumer['release']['pending']==[]
assert consumer['sceneInvalid'] is True and consumer['materialInvalid'] is True and consumer['tokenCurrent'] is False and consumer['currentSceneNull'] is True
assert consumer['afterRelease']=={'bodies':0,'shapes':0,'contacts':0,'joints':0,'liveBytes':'36096'} and consumer['resourcesAfterRelease']==[]
close=consumer['close'];assert close['status']=='released' and close['pending']==close['failures']==[]
physics=close['physicsPreparation'];assert physics['status']=='closed' and physics['originalError'] is None and physics['cleanupErrors']==[]
assert [(x['resource'],x['cleanup'],x['retained']) for x in physics['acquired']]==[('module','released',[]),('world','released',[])]
module=consumer['moduleRelease'];assert module==physics['moduleRelease'] and module['status']=='VERIFIED' and module['verified'] is True and module['errors']==[]
assert module['baseline']==module['terminal']
for snapshot in [module['baseline'],module['terminal']]:
 assert snapshot['schema']=='air-box3d-module-release-snapshot-v1' and snapshot['schemaVersion']==1
 assert set(snapshot['core'])=={'worlds','trackedRequestedBytes'} and len(snapshot['bridge'])==10 and len(snapshot['mesh'])==5
 for group in ['core','bridge','mesh']:assert all(type(v) is int and v==0 for v in snapshot[group].values())
assert consumer['qualification']['afterCloseNativeProbe']=='NOT_CALLED'
assert consumer['qualification']['allNativeHandles']==consumer['qualification']['heapOrGC']==consumer['qualification']['fullC20']==consumer['qualification']['I05']==consumer['qualification']['I06']=='NOT_QUALIFIED'
assert consumer['inputsUnchanged'] is True and consumer['hostClosed'] is True and consumer['hostErrors']==consumer['journalErrors']==[]
for k in ['error','closeError','inputError','journalError','hostCloseError','validationError']:assert k not in consumer
assert sha(O/'main/run/result/observations.raw.jsonl')==consumer['journal']['sha256']
assert sha(O/'preparation/input-lock.json')==consumer['lockSha256']==sha(O/'main/run/result/input-lock.json')
journal=[__import__('json').loads(x) for x in (O/'main/run/result/observations.raw.jsonl').read_text().splitlines()]
assert [r['sequence'] for r in journal]==list(range(1,len(journal)+1))
assert [r['value'] for r in journal if r['kind']=='module-release-frame']==consumer['frames']
terminal=[r for r in journal if r['kind']=='module-release-terminal-receipt'];assert len(terminal)==1 and terminal[0]['value']['moduleRelease']==module and terminal[0]['value']['close']==close
assert read(P/'result-validation-cpu.json')['status']=='PASS_PURE_READ_ORIGINAL_VALIDATORS'
closures={k:read(O/p) for k,p in [('freeze','preparation/freeze/closure.json'),('main','main/closure.json'),('postverify','preparation/postverify/closure.json')]}
for name,c in closures.items():
 assert c['subreaper'] is True and c['waitpidECHILD'] is True and c['waitpidScope']=='ALL_CHILDREN_-1' and c['remainingDescendants']==[] and c['remainingProcessGroup']==[] and c['budgetViolation'] is None and c['errors']==[]
 assert c['rawReturnCode']==0
 assert c['status']=='PHYSICALLY_CLOSED'
 assert c['closeSeconds']<=4
protected=read(O/'preparation/protected-inputs.json')['files']
for r in protected:verify(r)
assert len(protected)==3072 and result['protectedInputChanges']==[] and result['postverifyPassed'] is True
base=read(P/'source-before.json');assert inventory(Path(base['root']))==base['records']
expected={r['path']:r for r in base['records']}
for r in prep['overlay']:expected[r['path']]={'kind':'file',**r}
assert {r['path']:r for r in inventory(X)}==expected
st=read(P/'st-copy.json');assert inventory(Path(st['original']))==st['records']==inventory(Path(st['copy']))
assert len(st['records'])==1006 and sum(r.get('bytes',0) for r in st['records'])==53410229
for r in lock['sdk']:verify(r,Path(prep['sdk']))
assert {r['path'] for r in inventory(Path(prep['sdk']))}=={r['path'] for r in lock['sdk']}
for r in prep['originalReceipts']:verify(r)
for r in lock['provenance']['receipts'].values():verify(r,P/'evidence')
deps=Path(lock['provenance']['dependenciesRoot']);assert (X/'node_modules').resolve()==deps
actual={r['path']:r for r in inventory(deps)};expecteddeps=lock['dependencies']['rows'];actualpaths={'.'}
for current,dirs,files in os.walk(deps,followlinks=False):
 for name in dirs+files:actualpaths.add((Path(current)/name).relative_to(deps).as_posix())
assert actualpaths=={r['path'] for r in expecteddeps}
for r in expecteddeps:
 path=deps if r['path']=='.' else deps/r['path'];s=path.lstat();assert stat.S_IMODE(s.st_mode)==r['mode']
 if r['kind']=='file':assert stat.S_ISREG(s.st_mode);verify(r,deps)
 elif r['kind']=='directory':assert stat.S_ISDIR(s.st_mode)
 else:assert stat.S_ISLNK(s.st_mode) and os.readlink(path)==r['target'] and path.resolve().relative_to(deps).as_posix()==r['resolved']
assert result['preparationOutputBytes']==size(O/'preparation')
assert result['retainedOutputBytesIncludingSummary']==size(O)
mainbytes=size(O/'main');assert mainbytes<56*1024**2
files=[O/'result.json',O/'main/closure.json',O/'main/run/process.raw.json',O/'main/run/result/consumer.raw.json',O/'main/run/result/observations.raw.jsonl',O/'preparation/input-lock.json',O/'preparation/protected-inputs.json',O/'preparation/freeze/closure.json',O/'preparation/postverify/closure.json',P/'preparation-result.json',P/'publication-receipt.json',P/'postcheck.py']
summary={'status':'PASS_READ_ONLY_POSTCHECK_OF_MODULE_TERMINAL_PUBLIC_SUBSET','runtimeOutcome':'PASS_PUBLIC_MODULE_RELEASE_SUBSET; no repeat','scenes':1,'completedPublicFrames':2,'nonemptyCounts':consumer['nonempty'],'activeResources':consumer['activeResources'],'debugPrimitives':len(consumer['debug']['primitives']),'debugRetainedAfterClose':True,'afterRelease':consumer['afterRelease'],'resourcesAfterRelease':consumer['resourcesAfterRelease'],'moduleRelease':module,'normalFixtureClose':'released','physicsCleanup':'module/world released','fallbackCloseCalls':0,'physicalClosure':'ALL_CHILDREN_ECHILD; main child exit0','qualification':consumer['qualification'],'immutableBoundary':'Runtime copied receipt/debug observations plus source/CPU semantics; no retained module probe, no GC claim','protectedRecords':len(protected),'protectedUniquePaths':len({r['path'] for r in protected}),'protectedDrift':[],'producerFullSourceEntries':len(base['records']),'executionSourceEntries':len(expected),'stCopyFilesEach':len(st['records']),'stCopyBytesEach':sum(r.get('bytes',0) for r in st['records']),'dependencies':{k:lock['dependencies'][k] for k in ['root','sha256','files','links','directories']},'sdkFiles':len(lock['sdk']),'sdkBytes':sum(r['bytes'] for r in lock['sdk']),'mainElapsedSeconds':closure['elapsedSeconds'],'closeSeconds':closure['closeSeconds'],'peakSampledDescendantRSSBytes':closure['peakSampledDescendantRSSBytes'],'rawExitCode':0,'budgetViolation':None,'sourceRuntimeIdentity':result['producerIdentity'],'outerExecSession':{'id':1526,'exitCode':0,'source':'Observed unified exec terminal; not a fabricated native process receipt'},'artifacts':[row(p) for p in files],'budget':{'mainBytes':mainbytes,'wrapperOutputBytes':size(O),'wrapperPreparationBytes':size(O/'preparation'),'externalPreparationBytesIncludingThisSummary':0,'combinedPreparationBytes':0,'combinedAllBytes':0,'limits':{'mainBytes':56*1024**2,'preparationBytes':8*1024**2,'combinedBytes':64*1024**2}}}
external=size(P)
for _ in range(20):
 b=len((json.dumps(summary,indent=2)+'\n').encode());total=external+b
 budget=summary['budget'];values=(total,budget['wrapperPreparationBytes']+total,budget['wrapperOutputBytes']+total)
 old=(budget['externalPreparationBytesIncludingThisSummary'],budget['combinedPreparationBytes'],budget['combinedAllBytes'])
 budget.update(externalPreparationBytesIncludingThisSummary=values[0],combinedPreparationBytes=values[1],combinedAllBytes=values[2])
 if old==values:break
assert summary['budget']['combinedPreparationBytes']<=8*1024**2 and summary['budget']['combinedAllBytes']<=64*1024**2
with (P/'postcheck.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
assert size(P)==summary['budget']['externalPreparationBytesIncludingThisSummary']
print(json.dumps({k:summary[k] for k in ['status','scenes','completedPublicFrames','debugPrimitives','protectedRecords','protectedUniquePaths','budget']}))
