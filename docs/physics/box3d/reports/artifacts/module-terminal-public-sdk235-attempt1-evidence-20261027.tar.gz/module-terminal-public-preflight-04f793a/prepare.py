"""Exact local preparation only; no SDK import, native call, build or dependency mutation."""
import os,stat,json,hashlib,shutil
from pathlib import Path
R=Path('/workspace/scratch/62d43a81bbde/box3d-recovery-20261027T0928')
C=R/'module-terminal-public-harness-a00306f-candidate';S=R/'sdk235-source'
X=R/'module-terminal-public-source-04f793a-attempt-1';P=R/'module-terminal-public-preflight-04f793a';E=P/'evidence'
EXPECTED='15b79b07fd766f4d920e8b6174e91ccbb6093ad4f59e98c8d653030191b50398'
PRODUCER='a00306f391c595e292bbcaedd0f757bc99ca4ead';FIXTURE='04f793a74cae1ccb1d1f19172c09006918a5ca95'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def record(p,relative=None):return {'path':relative or str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def write(p,value):
 with p.open('x') as f:json.dump(value,f,separators=(',',':'));f.write('\n')
def inventory(root):
 rows=[]
 def scan(p):
  st=p.lstat();rel=p.relative_to(root).as_posix()
  if stat.S_ISLNK(st.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)});return
  if stat.S_ISDIR(st.st_mode):
   for c in sorted(p.iterdir()):scan(c)
  else:
   assert stat.S_ISREG(st.st_mode);rows.append({'kind':'file',**record(p,rel)})
 scan(root);return rows
assert digest(C/'publish-manifest.json')==EXPECTED
publication=json.loads((C/'publication-receipt.json').read_text());assert publication['commit']==FIXTURE and publication['manifestSha256']==EXPECTED and publication['remoteRefReadback'] is True
shutil.copyfile(C/'publication-receipt.json',P/'publication-receipt.json')
manifest=json.loads((C/'publish-manifest.json').read_text());assert len(manifest['files'])==7
assert not X.exists() and not E.exists()
E.mkdir()
paths=json.loads((P/'actual-receipts.json').read_text())
assert set(paths)=={'native','esm','dts','dtsGates','dtsDriver'}
records={}; originals=[]
for key,(src,rel,expected) in paths.items():
 source=Path(src) if Path(src).is_absolute() else R/src
 assert digest(source)==expected
 dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
 records[key]=record(dest,rel);originals.append(record(source));assert digest(dest)==expected
native=json.loads((E/records['native']['path']).read_text());assert native['sourceProducer']==PRODUCER
relout=Path(native['budget']['out']).relative_to(S)
assert relout.as_posix()=='tools/physics/box3d/output/production-st-a00306f-attempt-1'
original_inventory=inventory(S)
shutil.copytree(S,X,symlinks=True)
assert inventory(X)==original_inventory
changes=[]
for item in manifest['files']:
 src=C/'source'/item['path'];expected=item['after'];assert src.stat().st_size==expected['bytes'] and digest(src)==expected['sha256']
 dst=X/item['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert digest(dst)==expected['sha256'];changes.append(record(dst,item['path']))
after=inventory(X);changed={r['path']:r for r in original_inventory};modified=[]
for r in after:
 if changed.get(r['path'])!=r:modified.append(r['path'])
assert set(modified)=={r['path'] for r in changes}
assert inventory(S)==original_inventory,'Producer source changed during preparation'
st_inventory=inventory(S/relout);assert st_inventory==inventory(X/relout)
assert (X/'node_modules').resolve()==(R/'dependencies/node_modules').resolve()
provenance={'schema':'air-box3d-public-module-release-producers-v1','schemaSha256':'8af84ffb85ce311e9693d378c70ca3c788896b8aeee228700bbddd61c0ca8a04','fixtureCommit':FIXTURE,'runtimeProducerCommit':PRODUCER,'nativeProducerCommit':PRODUCER,'runtimeBuildNumber':235,'nativeRelativeOutput':relout.as_posix(),'dependenciesRoot':str((R/'dependencies/node_modules').resolve()),'receipts':records}
write(E/'provenance.json',provenance)
write(P/'publication-binding.json',{'fixtureCommit':FIXTURE,'publicationProof':record(P/'publication-receipt.json'),'sourceManifest':record(C/'publish-manifest.json'),'publishedFiles':changes})
write(P/'source-before.json',{'root':str(S),'records':original_inventory})
write(P/'st-copy.json',{'original':str(S/relout),'copy':str(X/relout),'records':st_inventory,'files':len(st_inventory),'bytes':sum(r.get('bytes',0) for r in st_inventory)})
write(P/'preparation-result.json',{'status':'PASS_EXACT_LOCAL_PREPARATION_ONLY','runtime':'NOT_RUN_BY_PREPARATION','fixtureCommit':FIXTURE,'producerCommit':PRODUCER,'sourceRoot':str(X),'sdk':str(R/'sdk235-esm-attempt-1'),'st':str(X/relout),'producerRoot':str(S),'overlay':changes,'originalReceipts':originals,'sourceUnchanged':True,'preparedSourceFiles':len(after),'stFiles':len(st_inventory),'stBytes':sum(r.get('bytes',0) for r in st_inventory),'provenance':record(E/'provenance.json'),'script':record(P/'prepare.py')})
print(json.dumps({'status':'PASS_EXACT_LOCAL_PREPARATION_ONLY','source':str(X),'stFiles':len(st_inventory),'stBytes':sum(r.get('bytes',0) for r in st_inventory),'provenanceSha256':digest(E/'provenance.json')}),flush=True)
