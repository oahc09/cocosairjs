# Sphere-Capsule SDK231 public attempt 1 raw evidence

Preserved original FAIL: 0/4 qualified scenes, zero callbacks, one completed
public frame; the raw totalSteps=2 includes the second failed attempt. The
external mounted Node position write is rejected by the following actual
Box3DSceneTransform.preflight. One normal app close and bounded ECHILD closure
do not turn main exit 1 into a PASS.

CONTENTS.json lists exact original bytes and SHA-256. Paths are relative to the
original execution workspace. The original absolute paths inside receipts
remain unchanged. This package includes the report's 26 indexed originals,
CPU/process/supervision logs, lock, protection inventories and postcheck script
(including its initial CPU-only attribute-error draft). It excludes SDK/WASM
binaries, dependency package bodies, complete repository/engine source, frozen
source duplication and the duplicate consumer copy of the input lock. The
single failing fixture source is preserved because it is indexed evidence.
Non-secret exact build feature/path assignments remain in producer receipts;
no credentials, auth material or full environment dump is included.

This is not a self-contained rerun bundle, nor a later fixed-fixture result.
Historical APP230 success, earlier failures and unavailable evidence retain
their own separate qualification. No original file was modified.
