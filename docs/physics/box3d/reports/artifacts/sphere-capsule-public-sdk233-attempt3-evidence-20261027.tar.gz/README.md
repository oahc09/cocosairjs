# Sphere-Capsule SDK233 public attempt 3 raw evidence

PASS_PUBLIC_SPHERE_CAPSULE_SUBSET: four declared cases,25 public frames,
31 callbacks. The callback-destruction case records BOTH immediate step24
Node-valid/native2body1shape and next existing frame25 Node-invalid/native1body1shape.
All4 scene releases zero live counts/ledger36096; normal fixture close,0fallback,
module/world cleanup released, main exit0/ECHILD and3014 protected records0drift.
This finite headless subset is not full T15/C21/C20/I05/I06/browser/mobile.
Attempts1/2 remain FAIL under their own original fixture and evidence.

CONTENTS.json binds original bytes/SHA256. Includes all26 report-indexed
originals, raw journals, closure/lock/protection/postcheck/producer receipts,
supervision logs and the individually indexed public fixture source.
Excludes SDK/native binaries, dependency bodies, full source tree, duplicate
frozen imports/harness and duplicate consumer input lock. Exact non-secret
build assignments remain allowlisted. No original changed; no runtime rerun.
This archive is durable evidence, not a self-contained SDK rerun project.
