"""Exact local preparation only; no SDK import, native call, build or dependency mutation."""
import os,stat,json,hashlib,shutil
from pathlib import Path
R=Path('/workspace/scratch/62d43a81bbde/box3d-recovery-20261027T0928')
C=R/'sphere-capsule-public-deferred-harness-candidate';S=R/'sdk233-source'
X=R/'sphere-capsule-public-source-bfb170a-attempt-3';P=R/'sphere-capsule-public-preflight-bfb170a';E=P/'evidence'
EXPECTED='ce483b9268f24db474ffd3950f005e459aa3c85917cae6b1859150edbec349fa'
PRODUCER='3f7cf0fdc0148c3829f5e1c854d667ec2417e0fc';FIXTURE='bfb170a04f5c79c0209ede51b7675048b8d06ed1'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def record(p,relative=None):return {'path':relative or str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def write(p,value):
 with p.open('x') as f:json.dump(value,f,separators=(',',':'));f.write('\n')
def inventory(root):
 rows=[]
 def scan(p):
  st=p.lstat();rel=p.relative_to(root).as_posix()
  if stat.S_ISLNK(st.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)});return
  if stat.S_ISDIR(st.st_mode):
   for c in sorted(p.iterdir()):scan(c)
  else:
   assert stat.S_ISREG(st.st_mode);rows.append({'kind':'file',**record(p,rel)})
 scan(root);return rows
assert digest(C/'publish-manifest.json')==EXPECTED
publication=json.loads((C/'publication-receipt.json').read_text());assert publication['commit']==FIXTURE and publication['manifestSha256']==EXPECTED and publication['remoteRefReadback'] is True
shutil.copyfile(C/'publication-receipt.json',P/'publication-receipt.json')
manifest=json.loads((C/'publish-manifest.json').read_text());assert len(manifest['files'])==3
assert not X.exists() and not E.exists()
E.mkdir()
paths=json.loads((P/'actual-receipts.json').read_text())
assert set(paths)=={'native','esm','dts','dtsGates','dtsDriver'}
records={}; originals=[]
for key,(src,rel,expected) in paths.items():
 source=Path(src) if Path(src).is_absolute() else R/src
 assert digest(source)==expected
 dest=E/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
 records[key]=record(dest,rel);originals.append(record(source));assert digest(dest)==expected
native=json.loads((E/records['native']['path']).read_text());assert native['sourceProducer']==PRODUCER
relout=Path(native['budget']['out']).relative_to(S)
assert relout.as_posix()=='tools/physics/box3d/output/production-st-3f7cf0f-attempt-1'
original_inventory=inventory(S)
shutil.copytree(S,X,symlinks=True)
assert inventory(X)==original_inventory
changes=[]
for item in manifest['files']:
 src=C/'source'/item['path'];expected=item['after'];assert src.stat().st_size==expected['bytes'] and digest(src)==expected['sha256']
 dst=X/item['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert digest(dst)==expected['sha256'];changes.append(record(dst,item['path']))
after=inventory(X);changed={r['path']:r for r in original_inventory};modified=[]
for r in after:
 if changed.get(r['path'])!=r:modified.append(r['path'])
assert set(modified)=={r['path'] for r in changes}
assert inventory(S)==original_inventory,'Producer source changed during preparation'
st_inventory=inventory(S/relout);assert st_inventory==inventory(X/relout)
assert (X/'node_modules').resolve()==(R/'dependencies/node_modules').resolve()
provenance={'schema':'air-box3d-public-sphere-capsule-producers-v1','schemaSha256':'d23be6157ee158ade877202b5e38d40978682cbd4794089c763e3ac8a79242a8','fixtureCommit':FIXTURE,'runtimeProducerCommit':PRODUCER,'nativeProducerCommit':PRODUCER,'runtimeBuildNumber':233,'nativeRelativeOutput':relout.as_posix(),'dependenciesRoot':str((R/'dependencies/node_modules').resolve()),'receipts':records}
write(E/'provenance.json',provenance)
write(P/'publication-binding.json',{'fixtureCommit':FIXTURE,'publicationProof':record(P/'publication-receipt.json'),'sourceManifest':record(C/'publish-manifest.json'),'publishedFiles':changes})
write(P/'source-before.json',{'root':str(S),'records':original_inventory})
write(P/'st-copy.json',{'original':str(S/relout),'copy':str(X/relout),'records':st_inventory,'files':len(st_inventory),'bytes':sum(r.get('bytes',0) for r in st_inventory)})
write(P/'preparation-result.json',{'status':'PASS_EXACT_LOCAL_PREPARATION_ONLY','runtime':'NOT_RUN_BY_PREPARATION','fixtureCommit':FIXTURE,'producerCommit':PRODUCER,'sourceRoot':str(X),'sdk':str(R/'sdk233-esm-attempt-1'),'st':str(X/relout),'producerRoot':str(S),'overlay':changes,'originalReceipts':originals,'sourceUnchanged':True,'preparedSourceFiles':len(after),'stFiles':len(st_inventory),'stBytes':sum(r.get('bytes',0) for r in st_inventory),'provenance':record(E/'provenance.json'),'script':record(P/'prepare.py')})
print(json.dumps({'status':'PASS_EXACT_LOCAL_PREPARATION_ONLY','source':str(X),'stFiles':len(st_inventory),'stBytes':sum(r.get('bytes',0) for r in st_inventory),'provenanceSha256':digest(E/'provenance.json')}),flush=True)
