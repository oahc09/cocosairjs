"""Read-only postchecks plus one exclusive summary; never imports SDK or advances physics."""
import os,stat,json,hashlib
from pathlib import Path
R=Path('/workspace/scratch/62d43a81bbde/box3d-recovery-20261027T0928');P=R/'sphere-capsule-public-preflight-6a69500';O=R/'sphere-capsule-public-attempt-2';X=R/'sphere-capsule-public-source-6a69500-attempt-2'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def row(p):return {'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify(record,base=None):
 p=(base/record['path']) if base else Path(record['path']);assert stat.S_ISREG(p.lstat().st_mode);assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],str(p)
def inventory(root):
 rows=[]
 def scan(p):
  s=p.lstat();rel=p.relative_to(root).as_posix()
  if stat.S_ISLNK(s.st_mode):rows.append({'path':rel,'kind':'symlink','target':os.readlink(p)});return
  if stat.S_ISDIR(s.st_mode):
   for c in sorted(p.iterdir()):scan(c)
  else:
   assert stat.S_ISREG(s.st_mode);rows.append({'kind':'file','path':rel,'bytes':s.st_size,'sha256':sha(p)})
 scan(root);return rows
def size(root):
 assert stat.S_ISDIR(root.lstat().st_mode)
 def fail(e):raise e
 total=0
 for current,dirs,files in os.walk(root,onerror=fail,followlinks=False):
  for d in dirs:assert stat.S_ISDIR((Path(current)/d).lstat().st_mode)
  for f in files:
   v=(Path(current)/f).lstat();assert stat.S_ISREG(v.st_mode);total+=v.st_size
 return total
result=read(O/'result.json');consumer=read(O/'main/run/result/consumer.raw.json');process=read(O/'main/run/process.raw.json');closure=read(O/'main/closure.json');lock=read(O/'preparation/input-lock.json');prep=read(P/'preparation-result.json')
assert result['status']=='FAIL_OR_PARTIAL' and result['rawReturnCode']==1 and result['allDescendantsClosed'] is True
assert process['status']=='FAIL' and [(r['label'],r['status'],r['signal']) for r in process['processes']]==[('cpu-controls',0,None),('consumer',1,None)]
assert consumer['status']=='FAIL' and consumer['totalSteps']==25 and len(consumer['frames'])==25
assert consumer['frames']==[{'step':n,'dt':1/60,'afterDraw':True} for n in range(1,26)]
assert len(consumer['cases'])==4
assert [c['name'] for c in consumer['cases']]==['sphere-created-first','capsule-created-first','zero-capsule-positive-capsule','callback-destroys-peer']
assert [c['status'] for c in consumer['cases']]==['PASS','PASS','PASS','RUNNING']
assert [len(c['events']) for c in consumer['cases']]==[10,10,10,1]
assert [len(c['rawEvents']) for c in consumer['cases']]==[10,10,10,1]
for c in consumer['cases']:
 assert c['release']['status']=='released' and c['release']['physicsSceneRelease']['status']=='RESTORED'
 assert c['release']['pending']==[] and c['release']['failures']==[]
 assert c['sceneInvalid'] is True and c['tokenCurrent'] is False and c['currentSceneNull'] is True and c['stepsDuringRelease']==0 and c['retainedCopiesUnchanged'] is True
 assert c['afterRelease']=={'bodies':0,'shapes':0,'contacts':0,'joints':0,'liveBytes':'36096'} and c['resources']==[]
for c in consumer['cases'][:3]:
 for role in ['round','capsule']:
  assert [e['type'] for e in c['events'] if e['self']==role]==['onCollisionEnter','onCollisionStay','onCollisionStay','onCollisionStay','onCollisionExit']
case=consumer['cases'][3]
assert len(case['events'])==1 and case['events'][0]['type']=='onCollisionEnter' and case['destroyRequested'] is True
assert case['destroyedPeerInvalid'] is False and case['afterCallback']=={'bodies':2,'shapes':1,'contacts':0,'joints':0,'liveBytes':'181716'}
assert case['snapshots'][-1]=={'step':25,'bodies':1,'shapes':1,'contacts':0,'joints':0,'liveBytes':'181716'}
assert 'false !== true' in consumer['error'] and 'public-contract.mjs:128:16' in consumer['error']
assert 'External Node pose/parent/scale' not in consumer['error']
assert consumer['appCreateCalls']==1 and consumer['fixtureOwnCloseObserved'] is True and consumer['fallbackCloseCalls']==0
close=consumer['close'];assert close['status']=='released' and close['physicsSceneRelease']['status']=='RESTORED' and close['pending']==[] and close['failures']==[]
physics=close['physicsPreparation'];assert physics['status']=='closed' and physics['cleanupErrors']==[]
assert {(v['resource'],v['cleanup']) for v in physics['acquired']}=={('module','released'),('world','released')}
assert all(v['retained']==[] for v in physics['acquired'])
assert consumer.get('closeError') is None and consumer['inputsUnchanged'] is True and consumer['hostClosed'] is True and consumer['hostErrors']==[] and consumer['journalErrors']==[]
assert sha(O/'main/run/result/observations.raw.jsonl')==consumer['journal']['sha256']
assert sha(O/'preparation/input-lock.json')==consumer['lockSha256']==sha(O/'main/run/result/input-lock.json')
closures={k:read(O/p) for k,p in [('freeze','preparation/freeze/closure.json'),('main','main/closure.json'),('postverify','preparation/postverify/closure.json')]}
for name,c in closures.items():
 assert c['subreaper'] is True and c['waitpidECHILD'] is True and c['waitpidScope']=='ALL_CHILDREN_-1' and c['remainingDescendants']==[] and c['remainingProcessGroup']==[] and c['budgetViolation'] is None and c['errors']==[]
 assert c['rawReturnCode']==(1 if name=='main' else 0)
 assert c['status']==('FAIL' if name=='main' else 'PHYSICALLY_CLOSED')
 assert c['closeSeconds']<=4
protected=read(O/'preparation/protected-inputs.json')['files']
for r in protected:verify(r)
assert len(protected)==3012 and result['protectedInputChanges']==[] and result['postverifyPassed'] is True
base=read(P/'source-before.json');assert inventory(Path(base['root']))==base['records']
expected={r['path']:r for r in base['records']}
for r in prep['overlay']:expected[r['path']]={'kind':'file',**r}
assert {r['path']:r for r in inventory(X)}==expected
st=read(P/'st-copy.json');assert inventory(Path(st['original']))==st['records']==inventory(Path(st['copy']))
assert len(st['records'])==979 and sum(r.get('bytes',0) for r in st['records'])==53083918
for r in lock['sdk']:verify(r,Path(prep['sdk']))
assert {r['path'] for r in inventory(Path(prep['sdk']))}=={r['path'] for r in lock['sdk']}
for r in prep['originalReceipts']:verify(r)
for r in lock['provenance']['receipts'].values():verify(r,P/'evidence')
deps=Path(lock['provenance']['dependenciesRoot']);assert (X/'node_modules').resolve()==deps
actual={r['path']:r for r in inventory(deps)};expecteddeps=lock['dependencies']['rows'];actualpaths={'.'}
for current,dirs,files in os.walk(deps,followlinks=False):
 for name in dirs+files:actualpaths.add((Path(current)/name).relative_to(deps).as_posix())
assert actualpaths=={r['path'] for r in expecteddeps}
for r in expecteddeps:
 path=deps if r['path']=='.' else deps/r['path'];s=path.lstat();assert stat.S_IMODE(s.st_mode)==r['mode']
 if r['kind']=='file':assert stat.S_ISREG(s.st_mode);verify(r,deps)
 elif r['kind']=='directory':assert stat.S_ISDIR(s.st_mode)
 else:assert stat.S_ISLNK(s.st_mode) and os.readlink(path)==r['target'] and path.resolve().relative_to(deps).as_posix()==r['resolved']
assert result['preparationOutputBytes']==size(O/'preparation')
assert result['retainedOutputBytesIncludingSummary']==size(O)
mainbytes=size(O/'main');assert mainbytes<56*1024**2
files=[O/'result.json',O/'main/closure.json',O/'main/run/process.raw.json',O/'main/run/result/consumer.raw.json',O/'main/run/result/observations.raw.jsonl',O/'preparation/input-lock.json',O/'preparation/protected-inputs.json',O/'preparation/freeze/closure.json',O/'preparation/postverify/closure.json',P/'preparation-result.json',P/'publication-receipt.json',P/'postcheck.py']
summary={'status':'PASS_READ_ONLY_POSTCHECK_OF_FAILED_ATTEMPT','runtimeOutcome':'FAIL; no retry','qualifiedCases':3,'declaredCases':4,'completedPublicFrames':25,'fixtureAttemptCounter':25,'callbacks':31,'firstNativeSnapshot':consumer['cases'][0]['snapshots'][0],'failedCaseImmediateSample':{'destroyedPeerInvalid':case['destroyedPeerInvalid'],'native':case['afterCallback']},'failedCaseNextFrameNativeSample':case['snapshots'][-1],'nextFrameNodeValidity':'NOT_RECORDED_NOT_INFERRED','priorCaseValidation':read(P/'case-validation-cpu.json'),'normalFixtureClose':'released','physicsCleanup':'module/world released','fallbackCloseCalls':0,'physicalClosure':'ALL_CHILDREN_ECHILD; main child exit1, not an application PASS','protectedRecords':len(protected),'protectedUniquePaths':len({r['path'] for r in protected}),'protectedDrift':[],'producerFullSourceEntries':len(base['records']),'executionSourceEntries':len(expected),'stCopyFilesEach':979,'stCopyBytesEach':53083918,'dependencies':{k:lock['dependencies'][k] for k in ['root','sha256','files','links','directories']},'sdkFiles':len(lock['sdk']),'sdkBytes':sum(r['bytes'] for r in lock['sdk']),'mainElapsedSeconds':closure['elapsedSeconds'],'closeSeconds':closure['closeSeconds'],'peakSampledDescendantRSSBytes':closure['peakSampledDescendantRSSBytes'],'rawExitCode':1,'budgetViolation':None,'sourceRuntimeIdentity':result['producerIdentity'],'outerExecSession':{'id':68984,'exitCode':1,'source':'Observed unified exec session terminal; not a fabricated process receipt'},'artifacts':[row(p) for p in files],'budget':{'mainBytes':mainbytes,'wrapperOutputBytes':size(O),'wrapperPreparationBytes':size(O/'preparation'),'externalPreparationBytesIncludingThisSummary':0,'combinedPreparationBytes':0,'combinedAllBytes':0,'limits':{'mainBytes':56*1024**2,'preparationBytes':8*1024**2,'combinedBytes':64*1024**2}}}
external=size(P)
for _ in range(20):
 b=len((json.dumps(summary,indent=2)+'\n').encode());total=external+b
 budget=summary['budget'];values=(total,budget['wrapperPreparationBytes']+total,budget['wrapperOutputBytes']+total)
 old=(budget['externalPreparationBytesIncludingThisSummary'],budget['combinedPreparationBytes'],budget['combinedAllBytes'])
 budget.update(externalPreparationBytesIncludingThisSummary=values[0],combinedPreparationBytes=values[1],combinedAllBytes=values[2])
 if old==values:break
assert summary['budget']['combinedPreparationBytes']<=8*1024**2 and summary['budget']['combinedAllBytes']<=64*1024**2
with (P/'postcheck.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
assert size(P)==summary['budget']['externalPreparationBytesIncludingThisSummary']
print(json.dumps({k:summary[k] for k in ['status','qualifiedCases','completedPublicFrames','fixtureAttemptCounter','protectedRecords','protectedUniquePaths','budget']}))
