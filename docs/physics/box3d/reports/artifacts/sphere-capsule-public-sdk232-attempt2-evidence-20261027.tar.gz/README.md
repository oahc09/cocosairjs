# Sphere-Capsule SDK232 public attempt 2 raw evidence

Original overall FAIL preserved. 25 completed public frames, 31 callbacks;
first three original validator cases PASS, fourth RUNNING/unqualified.
The fourth case retained immediate step24 Node invalid=false/native2body1shape.
Step25 native snapshot is1body1shape; Node validity was NOT resampled.
First failure validateCase:128 checks the saved immediate boolean.
All4 scene releases have zero live counts/ledger36096; normal close and ECHILD
do not turn main exit1 into public PASS. No repair or retry is represented.

CONTENTS.json binds exact original bytes and SHA256. Original receipt absolute
paths are unchanged. Included: all26 report-indexed originals, primary raw,
closure/lock/postcheck/protection inventories, necessary producer receipts,
process/supervision logs, and the indexed individual public fixture source.
Excluded: SDK/native binaries, dependency bodies, full source tree, duplicate
frozen harness/imports and duplicate consumer input lock. Exact non-secret
build feature/path assignments are allowlisted; no full environment dump.
This is not a self-contained rerun bundle. APP230 milestone, attempt1 FAIL and
all historical qualification boundaries remain unchanged. No original edited.
