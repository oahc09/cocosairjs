#version 300 es
#define CC_DEVICE_SUPPORT_FLOAT_TEXTURE 1
#define CC_EFFECT_USED_VERTEX_UNIFORM_VECTORS 48
#define CC_EFFECT_USED_FRAGMENT_UNIFORM_VECTORS 5
precision highp float;
uniform CCGlobal {
  highp   vec4 cc_time;
  mediump vec4 cc_screenSize;
  mediump vec4 cc_nativeSize;
  mediump vec4 cc_debug_view_mode;
};
uniform Constants {
  vec4 depthParams;
};
uniform highp sampler2D sceneDepth;
float sceneDepthVisibility(vec2 uv, float referenceDepth, float bias) { return step(referenceDepth - bias, texture(sceneDepth, uv).r); }
in highp vec2 sampleUV;
out vec4 cc_FragColor;
void main() { float d = texture(sceneDepth, sampleUV).r; float viewDistance = depthParams.x * depthParams.y / (depthParams.y - d * (depthParams.y - depthParams.x)); cc_FragColor = vec4(viewDistance / 10.0, sceneDepthVisibility(sampleUV, depthParams.z, depthParams.w), d, 1.0); }