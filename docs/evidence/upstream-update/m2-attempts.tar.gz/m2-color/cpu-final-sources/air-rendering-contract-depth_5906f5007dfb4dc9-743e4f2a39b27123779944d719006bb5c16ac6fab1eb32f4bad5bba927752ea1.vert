#version 300 es
#define CC_DEVICE_SUPPORT_FLOAT_TEXTURE 1
#define CC_EFFECT_USED_VERTEX_UNIFORM_VECTORS 48
#define CC_EFFECT_USED_FRAGMENT_UNIFORM_VECTORS 5
precision highp float;
uniform CCCamera {
  highp   mat4 cc_matView;
  highp   mat4 cc_matViewInv;
  highp   mat4 cc_matProj;
  highp   mat4 cc_matProjInv;
  highp   mat4 cc_matViewProj;
  highp   mat4 cc_matViewProjInv;
  highp   vec4 cc_cameraPos;
  mediump vec4 cc_surfaceTransform;
  mediump vec4 cc_screenScale;
  mediump vec4 cc_exposure;
  mediump vec4 cc_mainLitDir;
  mediump vec4 cc_mainLitColor;
  mediump vec4 cc_ambientSky;
  mediump vec4 cc_ambientGround;
  mediump vec4 cc_fogColor;
  mediump vec4 cc_fogBase;
  mediump vec4 cc_fogAdd;
  mediump vec4 cc_nearFar;
  mediump vec4 cc_viewPort;
};
uniform CCLocal {
  highp mat4 cc_matWorld;
  highp mat4 cc_matWorldIT;
  highp vec4 cc_lightingMapUVParam;
  highp vec4 cc_localShadowBias;
};
uniform Constants {
  vec4 depthParams;
};
in vec3 a_position;
out highp vec2 sampleUV;
void main() { sampleUV = a_position.xy * 0.5 + 0.5; gl_Position = cc_matViewProj * cc_matWorld * vec4(a_position, 1.0); }