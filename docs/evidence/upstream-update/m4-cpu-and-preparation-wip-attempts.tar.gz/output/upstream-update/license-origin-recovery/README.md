# Original Cocos license-source recovery

Status: BLOCKED_PINNED_COMMIT_NOT_FOUND. No license-origin verification pass is claimed.

The documented repository `cocos-creator/engine` officially redirects to `cocos/cocos-engine`; both API identities resolve to repository ID 47440536. This preserves repository identity and does not substitute a ref.

The exact requested commit `557b06f7e636572a15a426eb8c2387f40b92798a` was not available from that repository. Git commit API: 404 `Not Found`. REST commit API: 422 `No commit found for SHA: 557b06f7e636572a15a426eb8c2387f40b92798a`. Contents API for the pinned glslang license: 404 `No commit found for the ref 557b06f7e636572a15a426eb8c2387f40b92798a`.

No original blobs were materialized. No replacement refs, third-party repositories, or candidate license copies were used. The original verifier was not rerun because its original-source prerequisite is still absent. No full original Cocos tree or file-map comparison was established. Existing source, tests, tools, docs, snapshots, packages, and build artifacts were not modified by this recovery task.

The numbered JSON files preserve the returned connector evidence. `recovery-attempt-manifest.json` records scope, source identity, exact errors, and unmodified verifier identity. A complete original snapshot or a verified official source containing the exact pinned commit is still needed.
